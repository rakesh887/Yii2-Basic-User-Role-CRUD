<?php
namespace app\controllers;

use Yii;
use yii\web\Controller;
use app\models\User;

class SignupController extends Controller
{
    public $layout = false;

    public function actionIndex()
    {
        $model = new User();
        $model->role = 'user';

        if ($model->load(Yii::$app->request->post()) && $model->validate()) {
            $model->password = Yii::$app->security->generatePasswordHash($model->password);
            $model->created_at = time();

            if($model->save()) {
                Yii::$app->user->login($model);
                return $this->redirect(['dashboard/index']);
            }
        }

        return $this->render('index', [
            'model' => $model,
        ]);
    }

    public function beforeAction($action)
    {
        $this->enableCsrfValidation = false;
        return parent::beforeAction($action);
    }
}
