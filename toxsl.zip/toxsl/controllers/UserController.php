<?php
namespace app\controllers;

use Yii;
use yii\web\Controller;
use app\models\Userrole;
use app\models\User;
use yii\data\ActiveDataProvider;
use yii\web\NotFoundHttpException;
use yii\web\ForbiddenHttpException;

class UserController extends Controller
{
    public $layout = 'main';

    public function behaviors()
    {
        return [
            'access' => [
                'class' => \yii\filters\AccessControl::class,
                'only' => ['index', 'create', 'update', 'delete'],
                'rules' => [
                    [
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
                'denyCallback' => function ($rule, $action) {
                    return Yii::$app->response->redirect(['login/index']);
                },
            ],
        ];
    }

    public function actionIndex()
    {
        $dataProvider = new ActiveDataProvider([
            'query' => User::find(),
            'pagination' => ['pageSize' => 10],
        ]);

        return $this->render('index',['dataProvider'=>$dataProvider]);
    }

    public function actionCreate()
    {
        $model = new User();
        $data=array();

        if($model->load(Yii::$app->request->post())){
            if (!empty($model->password)) {
                $model->password = Yii::$app->security->generatePasswordHash($model->password);
            }

            if($model->save()){
                Yii::$app->session->setFlash('success','User created successfully.');
                return $this->redirect(['index']);
            }
        }

        $data['model'] = $model;
       
        return $this->render('form', $data);
    }

    public function actionUpdate($id)
    {
        $model = $this->findModel($id);
        $oldPassword = $model->password;
        $data=array();
        if($model->load(Yii::$app->request->post())){
            if (!empty($model->password)) {
                $model->password = Yii::$app->security->generatePasswordHash($model->password);
            } else {
                $model->password = $oldPassword;
            }
            if($model->save()){
                Yii::$app->session->setFlash('success','User updated successfully.');
                return $this->redirect(['index']);
            }
        }

        $data['model'] = $model;
        
        return $this->render('form', $data);
    }

    public function actionDelete($id)
    {
        $this->findModel($id)->delete();
        Yii::$app->session->setFlash('success','User deleted successfully.');
        return $this->redirect(['index']);
    }

    protected function findModel($id)
    {
        if(($model = User::findOne($id)) !== null){
            return $model;
        }
        throw new NotFoundHttpException('The requested project does not exist.');
    }

    public function beforeAction($action)
    {
        if (Yii::$app->user->isGuest) {
            return $this->redirect(['login/index']);
        }

        $role = Yii::$app->user->identity->role;
        $permissions = Userrole::getRolePermissions($role);

        if (!in_array('user', $permissions['access'])) {
            throw new ForbiddenHttpException('You do not have access to User.');
        }

        if (in_array($action->id, ['update','delete']) && !in_array('user', $permissions['modify'])) {
            throw new ForbiddenHttpException('You do not have permission to modify this user.');
        }

        $this->enableCsrfValidation = false;
        return parent::beforeAction($action);
    }
}
