<?php
namespace app\controllers;

use Yii;
use yii\web\Controller;
use app\models\Project;
use app\models\Userrole;
use yii\data\ActiveDataProvider;
use yii\web\NotFoundHttpException;
use yii\web\ForbiddenHttpException;

class ProjectController extends Controller
{
    public $layout = 'main';

    public function behaviors()
    {
        return [
            'access' => [
                'class' => \yii\filters\AccessControl::class,
                'only' => ['index', 'create', 'update', 'delete'],
                'rules' => [
                    [
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
                'denyCallback' => function ($rule, $action) {
                    return Yii::$app->response->redirect(['login/index']);
                },
            ],
        ];
    }

    public function actionIndex()
    {
        $dataProvider = new ActiveDataProvider([
            'query' => Project::find(),
            'pagination' => ['pageSize' => 10],
        ]);

        return $this->render('index',['dataProvider'=>$dataProvider]);
    }

    public function actionCreate()
    {
        $model = new Project();
        $data=array();

        if($model->load(Yii::$app->request->post())){
            if($model->save()){
                Yii::$app->session->setFlash('success','Project created successfully.');
                return $this->redirect(['index']);
            }
        }

        $data['model'] = $model;
       
        return $this->render('form', $data);
    }

    public function actionUpdate($id)
    {
        $model = $this->findModel($id);
        $data=array();
        if($model->load(Yii::$app->request->post()) && $model->save()){
            Yii::$app->session->setFlash('success','Project updated successfully.');
            return $this->redirect(['index']);
        }

        $data['model'] = $model;
        
        return $this->render('form', $data);
    }

    public function actionDelete($id)
    {
        $this->findModel($id)->delete();
        Yii::$app->session->setFlash('success','Project deleted successfully.');
        return $this->redirect(['index']);
    }

    protected function findModel($id)
    {
        if(($model = Project::findOne($id)) !== null){
            return $model;
        }
        throw new NotFoundHttpException('The requested project does not exist.');
    }

    public function beforeAction($action)
    {
        if (Yii::$app->user->isGuest) {
            return $this->redirect(['login/index']);
        }

        $role = Yii::$app->user->identity->role;
        $permissions = Userrole::getRolePermissions($role);

        if (!in_array('project', $permissions['access'])) {
            throw new ForbiddenHttpException('You do not have access to Project.');
        }

        if (in_array($action->id, ['update','delete']) && !in_array('project', $permissions['modify'])) {
            throw new ForbiddenHttpException('You do not have permission to modify this project.');
        }

        $this->enableCsrfValidation = false;
        return parent::beforeAction($action);
    }
}
