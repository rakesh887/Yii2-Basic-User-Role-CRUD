<?php
namespace app\controllers;

use Yii;
use yii\web\Controller;
use yii\web\ForbiddenHttpException;
use app\models\User;
use app\models\Project;
use app\models\Userrole;

class DashboardController extends Controller
{
    public $layout = 'main';

    public function actionIndex()
    {
        $totalUsers = User::find()->count();
        $totalProjects = Project::find()->count();

        return $this->render('index', [
            'totalUsers' => $totalUsers,
            'totalProjects' => $totalProjects,
        ]);
    }

    public function beforeAction($action)
    {
        if (Yii::$app->user->isGuest) {
            return $this->redirect(['login/index']);
        }

        $role = Yii::$app->user->identity->role;

        $permissions = Userrole::getRolePermissions($role);
        if (!in_array('dashboard', $permissions['access'])) {
            throw new ForbiddenHttpException('You do not have access to this page.');
        }

        return parent::beforeAction($action);
    }
}
