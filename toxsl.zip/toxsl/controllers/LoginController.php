<?php
namespace app\controllers;

use Yii;
use yii\web\Controller;
use app\models\Login;

class LoginController extends Controller
{
    public $layout = false;

    public function actionIndex()
    {
        $model = new Login();

        if ($model->load(Yii::$app->request->post()) && $model->login()) {
            Yii::$app->session->setFlash('success', 'Login successful!');
            return $this->redirect(['dashboard/index']);
        }

        return $this->render('index', [
            'model' => $model,
        ]);
    }

    public function actionLogout()
    {
        Yii::$app->user->logout();
        return $this->redirect(['login/index']);
    }

    public function beforeAction($action)
    {
        $this->enableCsrfValidation = false;
        return parent::beforeAction($action);
    }
}
