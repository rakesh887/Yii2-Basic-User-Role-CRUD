<?php
use yii\widgets\ActiveForm;
use yii\helpers\Html;
use app\models\Userrole;

$this->title = 'User';
?>

<div class="signup-box">
    <h2><?= $model->isNewRecord ? '<i class="fa fa-pencil"></i> Create User' : '<i class="fa fa-pencil"></i> Update User' ?></h2>

    <?php $form = ActiveForm::begin([
        'id' => 'user-form',
        'enableClientValidation' => true,
        'validateOnSubmit' => true,
        'options' => ['class' => 'form-horizontal'],
        'fieldConfig' => [
            'template' => "{label}\n{input}\n{error}",
            'errorOptions' => ['class' => 'col-lg-7 invalid-feedback'],
        ],
    ]); ?>

    <div class="form-group">
        <?= $form->field($model, 'name')->textInput([
            'placeholder' => 'Name',
            'class' => 'form-control'
        ]) ?>
    </div>

    <div class="form-group">
        <?= $form->field($model, 'email')->textInput([
            'placeholder' => 'E-Mail',
            'class' => 'form-control'
        ]) ?>
    </div>

    <div class="form-group">
        <?= $form->field($model, 'telephone')->textInput([
            'placeholder' => 'Telephone',
            'class' => 'form-control'
        ]) ?>
    </div>

    <div class="form-group">
        <?= $form->field($model, 'password')->passwordInput([
            'value' => '',
            'placeholder' => 'Password',
            'class' => 'form-control'
        ])->label('Password (leave blank to keep old)') ?>
    </div>

    <div class="form-group">
        <?= $form->field($model, 'role')
            ->dropDownList(
                Userrole::find()->select(['name','id'])->indexBy('id')->column()
            )->label('User Role') ?>
    </div>

    <div class="form-group">
        <?= $form->field($model, 'status')
            ->dropDownList([
                '1' => 'Enabled',
                '0' => 'Disabled'
            ]) ?>
    </div>

    <div class="form-group pull-right">
        <?= Html::submitButton('Save', ['class' => 'btn btn-primary']) ?>
        <?= Html::a('<i class="fa fa-reply"></i> Cancel', ['index'], ['class' => 'btn btn-light']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>

<style>
.invalid-feedback {
    display: block;
    padding-left: 0px;
    margin-top: 0px;
}

.signup-box {
    background: #fff;
    padding: 35px;
    border-radius: 12px;
    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
    animation: fadeIn 0.6s ease-in-out;
}
</style>
