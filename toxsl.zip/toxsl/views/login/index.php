<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;

$this->title = 'Signup';
?>
<div class="site-index">
    <div class="signup-box">
        <h2>Create Account</h2>

        <?php $form = ActiveForm::begin([
            'id' => 'login-form',
            'options' => ['class' => 'form-horizontal'],
            'fieldConfig' => [
                'template' => "{label}\n{input}\n{error}",
                'errorOptions' => ['class' => 'col-lg-7 invalid-feedback'],
            ],
        ]); ?>

        <div class="input-group">
            <?= $form->field($model, 'email')->textInput([
                'placeholder' => 'E-Mail',
                'class' => 'form-control'
            ])->label('E-Mail') ?>
        </div>

        <div class="input-group">
            <?= $form->field($model, 'password')->passwordInput([
                'placeholder' => 'Password',
                'class' => 'form-control'
            ])->label('Password') ?>
        </div>

        <?= $form->field($model, 'rememberMe')->checkbox([
            'template' => "<div class=\"custom-control custom-checkbox\">{input} {label}</div>\n<div class=\"col-lg-8\">{error}</div>",
        ]) ?>

        <div class="form-group">
            <?= Html::submitButton('Login', ['class' => 'btn']) ?>
        </div>

        <?php ActiveForm::end(); ?>

        <div class="login-link">
            Already have an account? <a href="index.php?r=signup/index">Signup</a>
        </div>
    </div>
</div>

<style>
body {
    font-family: Arial, sans-serif;
    background: linear-gradient(135deg, #4e73df, #1cc88a);
    height: 100vh;
    margin: 0;
    display: flex;
    justify-content: center;
    align-items: center;
}

.signup-box {
    background: #fff;
    width: 380px;
    padding: 35px;
    border-radius: 12px;
    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
    animation: fadeIn 0.6s ease-in-out;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(20px); }
    to   { opacity: 1; transform: translateY(0); }
}

.signup-box h2 {
    text-align: center;
    margin-bottom: 25px;
    color: #333;
    font-size: 26px;
    font-weight: bold;
}

.input-group {
    margin-bottom: 18px;
}

.input-group .form-control {
    width: 100%;
    height: 42px;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 8px;
    font-size: 15px;
    transition: 0.2s;
}

.input-group .form-control:focus {
    border-color: #4e73df;
    box-shadow: 0 0 5px rgba(78, 115, 223, 0.4);
}

.btn {
    width: 100%;
    background: #4e73df;
    border: none;
    padding: 12px;
    color: white;
    border-radius: 8px;
    font-size: 17px;
    cursor: pointer;
    transition: 0.3s;
    margin-top: 5px;
}

.btn:hover {
    background: #2e59d9;
}

.login-link {
    text-align: center;
    margin-top: 15px;
    font-size: 14px;
}

.login-link a {
    color: #4e73df;
    font-weight: bold;
    text-decoration: none;
}

.login-link a:hover {
    text-decoration: underline;
}
</style>
