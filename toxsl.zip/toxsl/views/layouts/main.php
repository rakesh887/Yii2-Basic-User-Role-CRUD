<?php
use yii\helpers\Html;
use yii\helpers\Url;

$this->beginPage();
?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/js/all.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css">

    <meta charset="<?= Yii::$app->charset ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= Html::encode($this->title) ?></title>
    <?php $this->head() ?>
    <style>
        body { margin:0; font-family: Arial,sans-serif; background:#f5f5f5; }
        .header { background:#4e73df; color:white; padding:15px 20px; display:flex; justify-content:space-between; align-items:center; }
        .sidebar { width:220px; background:#2e59d9; min-height:100vh; color:white; float:left; padding-top:20px; }
        .sidebar a { color:white; display:block; padding:12px 20px; text-decoration:none; }
        .sidebar a:hover { background:#fff; color:block;}
        .content { margin-left:220px; padding:20px; min-height:calc(100vh - 100px); }
        .footer { background:#f1f1f1; color:#555; padding:15px 20px; text-align:center; position:fixed; bottom:0; left:220px; width:calc(100% - 220px); }
    </style>
</head>
<body>
<?php $this->beginBody() ?>

<div class="header">
    <div class="logo"><h2>Dashboard</h2></div>
    <div class="user-info">
        <?php if(!Yii::$app->user->isGuest): ?>
            Hello, <?= Html::encode(Yii::$app->user->identity->name) ?> |
            <a href="<?= Url::to(['login/logout']) ?>" style="color:white; text-decoration:none;">Logout</a>
        <?php endif; ?>
    </div>
</div>

<div class="sidebar">
    <a href="<?= Url::to(['dashboard/index']) ?>"><i class="fa fa-dashboard"></i> Dashboard</a>
    <a href="<?= Url::to(['user/index']) ?>"><i class="fa fa-user"></i> Users</a>
    <a href="<?= Url::to(['userrole/index']) ?>"><i class="fa fa-users"></i> User Role</a>
    <a href="<?= Url::to(['project/index']) ?>"><i class="fa fa-book"></i> Projects</a>
</div>

<div class="content">
    <?= $content ?>
</div>

<div class="footer">
    &copy; <?= date('Y') ?> ToXSL. All rights reserved.
</div>

<?php $this->endBody() ?>
</body>
</html>
<?php $this->endPage() ?>
