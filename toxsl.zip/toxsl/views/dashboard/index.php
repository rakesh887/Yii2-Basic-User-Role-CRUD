<?php
/** @var yii\web\View $this */
/** @var int $totalUsers */
/** @var int $totalProjects */
$user = Yii::$app->user->identity;
$this->title = 'Dashboard';
?>

<h1>Welcome to <?= $user->roleName->name ?? 'N/A' ?> Dashboard!</h1>

<div class="dashboard-boxes">
    <div class="box user-box">
        <div class="icon">&#128100;</div>
        <div class="count"><?= $totalUsers ?></div>
        <div class="label">Total Users</div>
    </div>

    <div class="box project-box">
        <div class="icon">&#128221;</div>
        <div class="count"><?= $totalProjects ?></div>
        <div class="label">Total Projects</div>
    </div>
</div>

<style>
.dashboard-boxes {
    display: flex;
    gap: 20px;
    margin-top: 30px;
}

.box {
    flex:1;
    background: #4e73df;
    color:white;
    padding:30px;
    border-radius:10px;
    text-align:center;
    box-shadow:0 4px 15px rgba(0,0,0,0.1);
    transition:0.3s;
}

.box:hover {
    transform: translateY(-5px);
    box-shadow:0 8px 25px rgba(0,0,0,0.2);
}

.box .icon {
    font-size: 40px;
    margin-bottom: 15px;
}

.box .count {
    font-size: 36px;
    font-weight: bold;
}

.box .label {
    font-size: 18px;
    margin-top: 5px;
}

.user-box { background:#1cc88a; }
.project-box { background:#36b9cc; }
</style>
