<?php
use yii\widgets\ActiveForm;
use yii\helpers\Html;
$this->title = 'Project';
/** @var $model app\models\Role */
?>

<div class="signup-box">
    <h2><?= $model->isNewRecord ? '<i class="fa fa-pencil"></i> Create Project' : '<i class="fa fa-pencil"></i> Update Project' ?></h2>

    <?php $form = ActiveForm::begin([
        'id' => 'project-form',
        'options' => ['class' => 'form-horizontal'],
        'fieldConfig' => [
            'template' => "{label}\n{input}\n{error}",
            'errorOptions' => ['class' => 'col-lg-7 invalid-feedback'],
        ],
    ]); ?>

    <div class="form-group">
        <?= $form->field($model, 'title')->textInput([
            'placeholder' => 'Title',
            'class' => 'form-control'
        ])->label('Title') ?>
    </div>

    <div class="form-group">
        <?= $form->field($model, 'description')->textarea([
            'placeholder' => 'Description',
            'class' => 'form-control'
        ])->label('Description') ?>
    </div>

    <div class="form-group">
        <?= $form->field($model, 'status')->dropDownList(
            ['1' => 'Enabled', '0' => 'Disabled'],
        )->label('Status') ?>
    </div>
    
    <div class="form-group pull-right">
        <?= Html::submitButton('<i class="fa fa-save"></i> Save', ['class' => 'btn btn-primary']) ?>
        <?= Html::a('<i class="fa fa-reply"></i> Cancel', ['index'], ['class' => 'btn btn-light']) ?>
    </div>
</div>
<?php ActiveForm::end(); ?>

<style>
.signup-box {
    background: #fff;
    padding: 35px;
    border-radius: 12px;
    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
    animation: fadeIn 0.6s ease-in-out;
}
.invalid-feedback {
    display: block;
    padding-left: 0px;
    margin-top: 0px;
}
</style>