<?php
use yii\helpers\Html;
use yii\grid\GridView;

$this->title = 'Project';
?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2><i class="fa fa-list"></i> <?= Html::encode($this->title) ?></h2>
        <?= Html::a('<i class="fa fa-plus"></i> Create Project', ['create'], ['class' => 'btn btn-success']) ?>
    </div>

    <div class="table-responsive">
        <table class="table table-bordered table-hover">
            <thead class="thead-dark">
                <tr>
                    <th>#ID</th>
                    <th>Title</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($dataProvider->getModels() as $index => $project): ?>
                    <tr>
                        <td><?= Html::encode($project->id) ?></td>
                        <td><?= Html::encode($project->title) ?></td>
                        <td>
                            <?php if ($project->status == 1): ?>
                                <span class="badge badge-success">Enabled</span>
                            <?php else: ?>
                                <span class="badge badge-danger">Disabled</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?= Html::a('<i class="fa fa-pencil"></i> Edit', ['update', 'id' => $project->id], ['class' => 'btn btn-sm btn-primary']) ?>
                            <?= Html::a('<i class="fa fa-trash"></i> Delete', ['delete', 'id' => $project->id], [
                                'class' => 'btn btn-sm btn-danger',
                                'data' => [
                                    'confirm' => 'Are you sure you want to delete this project?',
                                    'method' => 'post',
                                ],
                            ]) ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css">
