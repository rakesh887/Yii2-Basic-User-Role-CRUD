<?php
use yii\widgets\ActiveForm;
use yii\helpers\Html;
$this->title = 'User Role';
/** @var $model app\models\Role */
?>

<div class="signup-box">
    <h2><?= $model->isNewRecord ? '<i class="fa fa-pencil"></i> Create Role' : '<i class="fa fa-pencil"></i> Update Role' ?></h2>

    <?php $form = ActiveForm::begin([
        'id' => 'userrole-form',
        'options' => ['class' => 'form-horizontal'],
        'fieldConfig' => [
            'template' => "{label}\n{input}\n{error}",
            'errorOptions' => ['class' => 'col-lg-7 invalid-feedback'],
        ],
    ]); ?>

    <div class="form-group">
        <?= $form->field($model, 'name')->textInput([
            'placeholder' => 'Name',
            'class' => 'form-control'
        ])->label('Name') ?>
    </div>

    <div class="form-group">
        <label>Access Permissions</label>
        <?php foreach($accessPermissions as $key => $label): ?>
        <div class="form-check">
            <input class="form-check-input" type="checkbox" name="Userrole[access_permission][]" value="<?= $label['value'] ?>"
                <?= is_array(explode(',', $model->access_permission)) && in_array($label['value'], explode(',', $model->access_permission)) ? 'checked' : '' ?>>
            <label class="form-check-label"><?= $label['text'] ?></label>
        </div>
        <?php endforeach; ?>
    </div>

    <div class="form-group">
        <label>Modify Permissions</label>
        <?php foreach($modifyPermissions as $key => $mlabel): ?>
        <div class="form-check">
            <input class="form-check-input" type="checkbox" name="Userrole[modify_permission][]" value="<?= $mlabel['value'] ?>"
                <?= is_array(explode(',', $model->modify_permission)) && in_array($mlabel['value'], explode(',', $model->modify_permission)) ? 'checked' : '' ?>>
            <label class="form-check-label"><?= $mlabel['text'] ?></label>
        </div>
        <?php endforeach; ?>
    </div>

    <div class="form-group pull-right">
        <?= Html::submitButton('<i class="fa fa-save"></i> Save', ['class' => 'btn btn-primary']) ?>
        <?= Html::a('<i class="fa fa-reply"></i> Cancel', ['index'], ['class' => 'btn btn-light']) ?>
    </div>
</div>
<?php ActiveForm::end(); ?>

<style>
.signup-box {
    background: #fff;
    padding: 35px;
    border-radius: 12px;
    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
    animation: fadeIn 0.6s ease-in-out;
}
.invalid-feedback {
    display: block;
    padding-left: 0px;
    margin-top: 0px;
}
</style>