<?php
use yii\helpers\Html;
use yii\grid\GridView;

$this->title = 'User Roles';
?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2><i class="fa fa-list"></i> <?= Html::encode($this->title) ?></h2>
        <?= Html::a('<i class="fa fa-plus"></i> Create Role', ['create'], ['class' => 'btn btn-success']) ?>
    </div>

    <div class="table-responsive">
        <table class="table table-bordered table-hover">
            <thead class="thead-dark">
                <tr>
                    <th>#ID</th>
                    <th>Role Name</th>
                    <th>Access Permissions</th>
                    <th>Modify Permissions</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($dataProvider->getModels() as $index => $role): ?>
                    <tr>
                        <td><?= Html::encode($role->id) ?></td>
                        <td><?= Html::encode($role->name) ?></td>
                        <td>
                            <?php
                            $access = explode(',', $role->access_permission);
                            foreach ($access as $perm) {
                                echo '<span class="badge badge-primary mr-1">' . Html::encode($perm) . '</span>';
                            }
                            ?>
                        </td>
                        <td>
                            <?php
                            $modify = explode(',', $role->modify_permission);
                            foreach ($modify as $perm) {
                                echo '<span class="badge badge-warning mr-1">' . Html::encode($perm) . '</span>';
                            }
                            ?>
                        </td>
                        <td>
                            <?= Html::a('<i class="fa fa-pencil"></i> Edit', ['update', 'id' => $role->id], ['class' => 'btn btn-sm btn-primary']) ?>
                            <?= Html::a('<i class="fa fa-trash"></i> Delete', ['delete', 'id' => $role->id], [
                                'class' => 'btn btn-sm btn-danger',
                                'data' => [
                                    'confirm' => 'Are you sure you want to delete this role?',
                                    'method' => 'post',
                                ],
                            ]) ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css">
