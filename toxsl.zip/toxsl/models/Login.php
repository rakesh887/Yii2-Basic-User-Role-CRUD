<?php
namespace app\models;

use Yii;
use yii\base\Model;
use app\models\User;

class Login extends Model
{
    public $email;
    public $password;
    public $rememberMe = true;

    private $_user = false;

    public function rules()
    {
        return [
            [['email', 'password'], 'required'],
            ['rememberMe', 'boolean'],
            ['email', 'email'],
        ];
    }

    public function login()
    {
        if (!$this->validate()) {
            return false;
        }

        $user = User::findOne(['email' => $this->email]);

        if (!$user) {
            $this->addError('email', 'Email not found.');
            return false;
        }

        if ($user->status != 1) {
            $this->addError('email', 'Your account is disabled. Please contact admin.');
            return false;
        }

        if (!Yii::$app->security->validatePassword($this->password, $user->password)) {
            $this->addError('password', 'Incorrect password.');
            return false;
        }
        
        Yii::$app->user->login($user, $this->rememberMe ? 3600*24*30 : 0);
        return true;
    }
}
