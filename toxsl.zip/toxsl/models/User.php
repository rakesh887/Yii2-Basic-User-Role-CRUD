<?php
namespace app\models;

use Yii;
use yii\db\ActiveRecord;
use yii\behaviors\TimestampBehavior;
use yii\web\IdentityInterface;

class User extends ActiveRecord implements IdentityInterface
{
    public static function tableName()
    {
        return 'user';
    }

    public function behaviors()
    {
        return [
            [
                'class' => TimestampBehavior::class,
                'attributes' => [
                    ActiveRecord::EVENT_BEFORE_INSERT => ['created_at','updated_at'],
                    ActiveRecord::EVENT_BEFORE_UPDATE => ['updated_at'],
                ],
                'value' => time(),
            ],
        ];
    }

    public function rules()
    {
        return [
            [['name','email','telephone','password'], 'required'],
            ['email','email'],
            ['email','unique'],
            ['telephone','string','max'=>15],
            ['password', 'required', 'on' => 'create'],
            ['password', 'safe'],
            ['password', 'string', 'min' => 6],
            ['role','string'],
            [['status'], 'in', 'range' => ['1', '0']],
        ];
    }

    public function getRoleName()
    {
        return $this->hasOne(Userrole::class, ['id' => 'role']);
    }

    public static function findIdentity($id)
    {
        return static::findOne($id);
    }

    public static function findIdentityByAccessToken($token, $type = null)
    {
        return null;
    }

    public function getId()
    {
        return $this->id;
    }

    public function getAuthKey()
    {
        return null;
    }

    public function validateAuthKey($authKey)
    {
        return true;
    }

    public function validatePassword($password)
    {
        return Yii::$app->security->validatePassword($password, $this->password);
    }
}
