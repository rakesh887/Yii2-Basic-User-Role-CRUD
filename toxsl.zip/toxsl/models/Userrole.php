<?php
namespace app\models;

use Yii;
use yii\db\ActiveRecord;
use yii\behaviors\TimestampBehavior;

class Userrole extends ActiveRecord
{
    public static function tableName()
    {
        return 'userrole';
    }

    public function behaviors()
    {
        return [
            [
                'class' => TimestampBehavior::class,
                'attributes' => [
                    ActiveRecord::EVENT_BEFORE_INSERT => ['created_at','updated_at'],
                    ActiveRecord::EVENT_BEFORE_UPDATE => ['updated_at'],
                ],
                'value' => time(),
            ]
        ];
    }

    public function rules()
    {
        return [
            [['name'],'required'],
            [['name'],'string','max'=>100],
            [['access_permission', 'modify_permission'],'safe'],
        ];
    }

    public function attributeLabels()
    {
        return [
            'name' => 'Role Name',
        ];
    }

    public static function getRolePermissions($role)
    {
        $roleModel = self::find()->where(['id' => $role])->one();
        if($roleModel){
            return [
                'access' => explode(',', $roleModel->access_permission),
                'modify' => explode(',', $roleModel->modify_permission),
            ];
        }
        return ['access'=>[], 'modify'=>[]];
    }

    public function getAccessPermissionsArray()
    {
        if (is_string($this->access_permission)) {
            return explode(',', $this->access_permission);
        }
        return (array)$this->access_permission;
    }

    public function getModifyPermissionsArray()
    {
        if (is_string($this->modify_permission)) {
            return explode(',', $this->modify_permission);
        }
        return (array)$this->modify_permission;
    }

    public function beforeSave($insert)
    {
        if (parent::beforeSave($insert)) {
            if (is_array($this->access_permission)) {
                $this->access_permission = implode(',', $this->access_permission);
            }
            if (is_array($this->modify_permission)) {
                $this->modify_permission = implode(',', $this->modify_permission);
            }
            return true;
        }
        return false;
    }

    public function AccessPermissions() {
        $permissions=[];
        $permissions[]=[
            'text'  => 'Dashboard',
            'value' => 'dashboard',
        ];
        $permissions[]=[
            'text'  => 'Projects',
            'value' => 'project',
        ];
        $permissions[]=[
            'text'  => 'Users',
            'value' => 'user',
        ];
        $permissions[]=[
            'text'  => 'User Role',
            'value' => 'userrole',
        ];
        return $permissions;
    }

    public function ModifyPermissions() {
        $permissions=[];
        $permissions[]=[
            'text'  => 'Projects',
            'value' => 'project',
        ];
        $permissions[]=[
            'text'  => 'Users',
            'value' => 'user',
        ];
        $permissions[]=[
            'text'  => 'User Role',
            'value' => 'userrole',
        ];
        return $permissions;
    }
}
